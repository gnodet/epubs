                                     README

   This zip file contains some examples on how you might put the Maven Docbkx
   Plugin to good use. All of the examples are discussed in the User Manual,
   found here:

   http://docbkx-tools.sourceforge.net/docbkx-samples/manual.html

   In order to run a build for one of the examples, simply type:

       mvn -f [name of the file] [docbkx goal]

   ..., with [docbkx goal] being one of the plugin's goals
   (docbkx:generate-html, docbkx:generate-pdf, etc.), and hit enter.
